function isOdd(num) {
  return num % 2 !== 0;
}

console.log(isOdd(5));
